#pragma once

#include "Config.h"
#include "Types.h"

void calibrateCurrentSensor(int samples = 100);
void initSOCFromVoltage(float cellVoltages[]);

void updateSOC(float currentA);
void updateSOH(float cellVoltages[]);


void estimateCellTemperatures(float group1Temp, float group2Temp, float currentA);

void printCellTemps();
extern float cellTemps[10];