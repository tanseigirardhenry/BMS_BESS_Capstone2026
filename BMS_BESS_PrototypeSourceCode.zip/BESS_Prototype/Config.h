#pragma once
#include <Arduino.h>
#include <vector>

// Pins
constexpr uint8_t PIN_BATTG1_TEMP = 18;   //RENAME (PIN_BATTG1_TEMP)
constexpr uint8_t PIN_ROOM_TEMP = 19;
constexpr uint8_t PIN_BATTG2_TEMP = 12;
  //constexpr uint8_t PIN_VOLTAGE   = 32;
constexpr uint8_t PIN_CURRENT   = 33;


// Multiplexer Control pins
constexpr uint8_t PIN_MUX_S0 = 12;
constexpr uint8_t PIN_MUX_S1 = 25;
constexpr uint8_t PIN_MUX_S2 = 26;
constexpr uint8_t PIN_MUX_S3 = 27;
constexpr uint8_t PIN_MUX_SIG = 32;   // ADC input from mux


// Voltage divider
constexpr float R_TOP = 100000.0f;
constexpr float R_BOTTOM = 27000.0f;
constexpr float VIN_MULTIPLIER = (R_TOP + R_BOTTOM) / R_BOTTOM;

// ACS724
constexpr float ACS_ZERO = 2.5f;
constexpr float ACS_SENS = 0.04f;
constexpr float R_ACS_TOP = 100000.0f;
constexpr float R_ACS_BOTTOM = 40000.0f;
constexpr float ACS_DIV_RATIO = (R_ACS_TOP + R_ACS_BOTTOM) / R_ACS_BOTTOM;

// Battery
constexpr float BATTERY_CAPACITY_mAh = 4000.0f;
constexpr float FULL_VOLTAGE = 4.2f;
constexpr float EMPTY_VOLTAGE = 2.5f;

// ADC
constexpr int ADC_SAMPLES = 20;

// Timing
constexpr unsigned long LOG_INTERVAL = 30UL * 1000UL;
constexpr size_t DISPLAY_INTERVAL_COUNT = 4;

// THRESHOLDS
constexpr float BATT_TEMP_THRESHOLD = 45.0f;
constexpr float OVERCURRENT_THRESHOLD = 1.5f;  
constexpr float UNDERVOLTAGE_THRESHOLD = 2.5f;  
constexpr float OVERVOLTAGE_THRESHOLD  = 4.25f;  

// Email timing
const unsigned long EMAIL_INTERVAL = 120000; // 2 minutes

// SD Card fail prevent
extern bool sdBusy;


// Globals (behavior-critical) for SOC & SOH alg
extern float current_offset;
extern float accumulated_mAh[10];
extern float soc_percent[10];
extern float soh_percent[10];
extern bool discharge_cycle_active[10];

extern unsigned long lastLogMs;
extern size_t samplesSinceDisplay;

// Overheat tracking
extern bool overheatOccurred;
extern float overheatMaxTemp;
extern unsigned long overheatFirstMs;




