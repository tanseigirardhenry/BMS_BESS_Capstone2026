#pragma once
#include "Config.h"
#include "Types.h"

//Intialization of sensors and MUX
void initTemperatureSensors();
void initADC();
void initMUX();

// Collection of mux voltages, and current
float readMuxVoltage(uint8_t channel);
void readCellVoltages(float cells[], uint8_t count);
float readCurrentACS724();

// Temp sensor data collection
float getBatteryGroup1Temp();   
float getBatteryGroup2Temp();
float getRoomTemp();

String formatTimestamp(unsigned long ms);
