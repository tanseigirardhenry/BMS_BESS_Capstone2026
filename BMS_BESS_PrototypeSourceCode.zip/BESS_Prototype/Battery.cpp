#include "Battery.h"
#include "Sensors.h"
#include "Types.h"

float accumulated_mAh[10] = {0};
float cycle_start_mAh[10] = {0};
float soc_percent[10] = {100};

float soh_percent[10] = {100};
bool discharge_cycle_active[10] = {false};


// Thermal model parameters 
static const float CELL_RESISTANCE = 0.002f;   // 2 milliohm per cell

// Position coefficients for 2-3-3-2 hex layout
static const float kp[10] = {
  0.93, 0.93,
  1.01, 1.12, 1.01,
  1.01, 1.12, 1.01,
  0.93, 0.93
};

float cellTemps[10];


// Calibrate SOC with OCV 
void initSOCFromVoltage(float cellVoltages[]) {
  for(int i = 0; i < 10; i++) {
    float v = cellVoltages[i];

    soc_percent[i] = constrain(
      (v - EMPTY_VOLTAGE) / (FULL_VOLTAGE - EMPTY_VOLTAGE) * 100.0f,
      0.0f, 100.0f);

    accumulated_mAh[i] =
      (1.0f - soc_percent[i] / 100.0f) * BATTERY_CAPACITY_mAh;
  }
}


// SOC+ alg
void updateSOC(float currentA)
{
  float dt = (millis() - lastLogMs) / 3600000.0f;

  for(int i = 0; i < 10; i++) {
    accumulated_mAh[i] += currentA * 1000.0f * dt;

    soc_percent[i] = constrain(
      100.0f - (accumulated_mAh[i] / BATTERY_CAPACITY_mAh) * 100.0f,
      0.0f, 100.0f);
  }
}


// SOH alg
void updateSOH(float cellVoltages[]) {

  for (int i = 0; i < 10; i++) {

    // Detect FULL → start cycle
    if (!discharge_cycle_active[i] && cellVoltages[i] >= FULL_VOLTAGE) {
      discharge_cycle_active[i] = true;

      // Save starting point instead of resetting anything
      cycle_start_mAh[i] = accumulated_mAh[i];
    }

    // Detect EMPTY → end cycle
    if (discharge_cycle_active[i] && cellVoltages[i] <= EMPTY_VOLTAGE) {

      float discharged_mAh =
        accumulated_mAh[i] - cycle_start_mAh[i];

      soh_percent[i] = constrain(
        (discharged_mAh / BATTERY_CAPACITY_mAh) * 100.0f,
        0.0f, 100.0f);

      discharge_cycle_active[i] = false;
    }
  }
}


// Per cell estimation alg
void estimateCellTemperatures(float group1Temp, float group2Temp, float currentA){
    float heating = currentA * currentA * CELL_RESISTANCE;

    // Cells 1–5 use group sensor 1
    for(int i = 0; i < 5; i++){
        cellTemps[i] = group1Temp + kp[i] * heating;
    }

    // Cells 6–10 use group sensor 2
    for(int i = 5; i < 10; i++){
        cellTemps[i] = group2Temp + kp[i] * heating;
    }
}

// Print format for temperature for serial Monitor
void printCellTemps(){

    for(int i = 0; i < 10; i++) {
        Serial.print("Cell ");
        Serial.print(i+1);
        Serial.print(": ");
        Serial.print(cellTemps[i],2);
        Serial.print(" C | ");
    }
}


