#include "Logging.h"
#include "Sensors.h"
#include "Battery.h"
#include "Types.h"

// Stores all readings collected since last display/reset
std::vector<Reading> readings;

// Timestamp of last log
unsigned long lastLogMs = 0;
// Counter to track how many samples have been taken since last display
size_t samplesSinceDisplay = 0;
// Flag to trigger email notification when a fault occurs
extern bool emailFaultPending;


// Fault state variables
FaultType activeFault = FAULT_NONE; // Current active fault
float overheatMaxTemp = NAN;        // Tracks highest temperature during fault
unsigned long overheatFirstMs = 0;  // Timestamp of first overheat event


// Print startup message to serial monitor 
void printBootMessage() {
  Serial.println();
  Serial.println("ESP32 DS18B20 x3 + voltage divider logger + ACS724-50A");
  Serial.println("Logging every 30s, display every 2 minutes (4 samples).");
  Serial.println();
}

Reading takeReading(unsigned long now) {
  Reading r;

  // Assign timestamp
  r.timestampMs = now;

  // Temperature readings
  r.battG1TempC = getBatteryGroup1Temp();   
  r.battG2TempC = getBatteryGroup2Temp();
  r.roomTempC = getRoomTemp();
  // Cell voltages
  readCellVoltages(r.cellVoltage, 10);
  // Module current measurement
  r.currentA = readCurrentACS724();
  return r;
}


// Stores reading and updates display counter
void logReading(const Reading& r) {
  readings.push_back(r);
  samplesSinceDisplay++;
}


// Printing for Cell voltages
void printCellVoltages(const Reading& r) {
    for(int i = 0; i < 10; i++) {
        Serial.print("Voltage Cell ");
        Serial.print(i + 1);
        Serial.print(": ");
        Serial.print(r.cellVoltage[i], 3);
        Serial.print(" V | ");
    }
}

// Printing format for SOC
void printCellSOC()
{
    for(int i = 0; i < 10; i++)
    {
        Serial.print("Cell ");
        Serial.print(i+1);
        Serial.print(" SOC: ");
        Serial.print(soc_percent[i],1);
        Serial.print("% | ");
    }
}

// Printing format for SOH
void printCellSOH()
{
    for(int i = 0; i < 10; i++)
    {
        Serial.print("Cell ");
        Serial.print(i+1);
        Serial.print(" SOC: ");
        Serial.print(soh_percent[i],1);
        Serial.print("% | ");
    }
}



  //Configuring fault triggering switch system
void triggerFault(FaultType type, const Reading& r) {

  if (activeFault != FAULT_NONE) return;  // Already latched

  activeFault = type;
   emailFaultPending = true; 

  Serial.println("\n=================================");
  Serial.println("!!! SYSTEM FAULT TRIGGERED !!!");
  Serial.println("=================================");

  switch (type) {
    case FAULT_THERMAL:
      Serial.println("Reason: Overtemperature");
      break;
    case FAULT_OVERCURRENT:
      Serial.println("Reason: Overcurrent");
      break;
    case FAULT_UNDERVOLTAGE:
      Serial.println("Reason: Undervoltage");
      break;
    case FAULT_OVERVOLTAGE:
      Serial.println("Reason: Overvoltage");
      break;
    default:
      break;
  }

 
  dumpReadings();

  Serial.println("\nSYSTEM HALTED");
  Serial.println("=================================");
}



// Overheat check
void checkThermal(const Reading& r) {
  
  for(int i = 0; i < 10; i++){
    if(cellTemps[i] > BATT_TEMP_THRESHOLD){
        Serial.print("Thermal Fault: Cell ");
        Serial.print(i + 1);
        Serial.println(" exceeded temperature limit");

        triggerFault(FAULT_THERMAL, r);
        //break;
    }
  }

}


// Overcurrent check
void checkOvercurrent(const Reading& r) {
  if (fabs(r.currentA) >= OVERCURRENT_THRESHOLD) {
    triggerFault(FAULT_OVERCURRENT, r);
  }
}


// under & over voltage check for all cells
void checkVoltageFault(const Reading& r)
{
  for(int i = 0; i < 10; i++) {
    if (r.cellVoltage[i] <= UNDERVOLTAGE_THRESHOLD) {
      Serial.print("Undervoltage detected on Cell ");
      Serial.println(i + 1);
      triggerFault(FAULT_UNDERVOLTAGE, r);
      return;
    }

    if (r.cellVoltage[i] >= OVERVOLTAGE_THRESHOLD){
      Serial.print("Overvoltage detected on Cell ");
      Serial.println(i + 1);
      triggerFault(FAULT_OVERVOLTAGE, r);
      return;
    }
  }
}

// Determines if it's time to display accumulated readings
bool shouldDisplay() {
  return samplesSinceDisplay >= DISPLAY_INTERVAL_COUNT;
}

// Serial Monitor display data format and dump
void dumpReadings() {
  Serial.println("===== Data dump =====");
  for (auto& r : readings) {
    Serial.print(formatTimestamp(r.timestampMs));
   
    Serial.print( " | ");
    printCellVoltages(r);
    Serial.print(" V | I ");
    Serial.print(r.currentA, 2);
    Serial.print(" A | ");
  

    printCellSOC();
    printCellSOH();

    Serial.print(" C | Room ");
    Serial.print(r.roomTempC, 2);
    Serial.print( " | ");
    printCellTemps();
   
  }

  Serial.println("=====================");
}

// Resets display interval and clears stored readin
void resetDisplayInterval() {
  readings.clear();   // Clear stored readings
  samplesSinceDisplay = 0;  // Reset counter

  // Reset fault-related tracking
  activeFault = FAULT_NONE;
  overheatMaxTemp = NAN;
  overheatFirstMs = 0;
}
