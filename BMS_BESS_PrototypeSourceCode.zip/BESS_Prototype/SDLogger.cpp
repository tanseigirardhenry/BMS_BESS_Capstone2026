#include "SDLogger.h"

#include "SD_MMC.h"
#include "Types.h"
#include "Sensors.h"
#include "Battery.h"


bool sdBusy = false;

// Initializes the SD card and creates the log file if it doesn't exist
void initSD() {
  Serial.println("Initializing SD card...");

  // Initialize SD card in 1-bit mode 
  if (!SD_MMC.begin("/sdcard", true, false, SDMMC_FREQ_DEFAULT)) {
    delay(100);
    Serial.println("SD initialization failed!");

    // Help debugging if intialization fails
    Serial.println(SD_MMC.cardSize());    // Tells size of SD card
    Serial.println(SD_MMC.cardType());    // Tell me SD card type
    return;
  }

  Serial.println("SD initialized.");

  // Print card size in MB
  uint64_t cardSize = SD_MMC.cardSize() / (1024 * 1024);
  Serial.print("SD Card Size: ");
  Serial.print(cardSize);
  Serial.println(" MB");

  // Create log file if it does not already exist
  if (!SD_MMC.exists("/log.csv")) {
    File file = SD_MMC.open("/log.csv", FILE_WRITE);

    // Column header creation for file
    if (file) {
     
      // Time labeling
      file.print("Time(ms)");

      //Voltage per cell labeling
      for(int i = 1; i <= 10; i++) {
        file.print(",cellVoltage");
        file.print(i);
      }

      // Current labeling
      file.print(",Current(A)");

      // Cell SOC labeling
      for(int i = 1; i <= 10; i++){
        file.print(",cellSOC");
        file.print(i);
      }

      // Cell SOH labeling
      for(int i = 1; i <= 10; i++){
        file.print(",cellSOH");
        file.print(i);
      }

      // Current labeling
      file.print(",RoomTemp(C)");

      // Per cell temp labeling
      for(int i = 1; i <= 10; i++)
      {
        file.print(",cellTemp");
        file.print(i);
      }

      file.println();
      file.close();
      Serial.println("Log file created.");
    }
  }
}


// Logs data to SD card file in csv format
void logToSD(const Reading& r) {

  if (sdBusy) return;   // prevent conflict with email
  sdBusy = true;

  // Open file to add data values
  File file = SD_MMC.open("/log.csv", FILE_APPEND);

  if (file) {
    // Write new row of data
    file.print((formatTimestamp(r.timestampMs)));
    file.print(",");

    // For per cell voltages
    for(int i = 0; i < 10; i++){
      file.print(r.cellVoltage[i], 3); // 3 decimal places
      file.print(",");
    }

    // Module Current
    file.print(r.currentA);

    // For per cell SOC
    for(int i = 0; i < 10; i++){
      file.print(",");
      file.print(soc_percent[i],1); // 1 decimal place
    }

    // For SOH
    for(int i = 0; i < 10; i++){
      file.print(",");
      file.print(soh_percent[i],1); // 1 decimal place
    }

    // room temp
    file.print(",");
    file.print(r.roomTempC);

    // For per cell temp
    for(int i = 0; i < 10; i++){
      file.print(",");
      file.print(cellTemps[i],2); // 2 decimal places
    }

    file.println(); // End of CSV row
    file.close();

    // Small delay to ensure SD write completes
    delay(10);
  } else {
    Serial.println("SD write failed.");
  }

  // Unlock SD access
    sdBusy = false;
}