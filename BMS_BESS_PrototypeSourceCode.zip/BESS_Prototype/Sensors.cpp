#include "Sensors.h"
#include "Types.h"

#include <OneWire.h>
#include <DallasTemperature.h>
#include "driver/adc.h"
#include "esp_adc_cal.h"

OneWire oneWireBatt(PIN_BATTG1_TEMP);   
OneWire oneWireBatt2(PIN_BATTG2_TEMP); 
OneWire oneWireRoom(PIN_ROOM_TEMP);

DallasTemperature sensorsBatt(&oneWireBatt);
DallasTemperature sensorsBatt2(&oneWireBatt2);
DallasTemperature sensorsRoom(&oneWireRoom);

esp_adc_cal_characteristics_t adc_chars_voltage;
esp_adc_cal_characteristics_t adc_chars_current;

// Select MUX channel
static void selectMuxChannel(uint8_t channel)
{
  digitalWrite(PIN_MUX_S0, channel & 1);
  digitalWrite(PIN_MUX_S1, (channel >> 1) & 1);
  digitalWrite(PIN_MUX_S2, (channel >> 2) & 1);
  digitalWrite(PIN_MUX_S3, (channel >> 3) & 1);
}

float current_offset = 0.0f;

// Tell temperature sensors to start measuring
void initTemperatureSensors() {
  sensorsBatt.begin();
  sensorsBatt2.begin();
  sensorsRoom.begin();
}

// Set attent- for current sensor port on esp32
void initADC() {
  analogReadResolution(12);

  analogSetPinAttenuation(PIN_CURRENT, ADC_2_5db);

  esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_DB_0,
                           ADC_WIDTH_BIT_12, 1100,
                           &adc_chars_voltage);

  esp_adc_cal_characterize(ADC_UNIT_1, ADC_ATTEN_DB_2_5,
                           ADC_WIDTH_BIT_12, 1100,
                           &adc_chars_current);
}

// Seperate ADC function for MUX
void initMUX()
{
  pinMode(PIN_MUX_S0, OUTPUT);
  pinMode(PIN_MUX_S1, OUTPUT);
  pinMode(PIN_MUX_S2, OUTPUT);
  pinMode(PIN_MUX_S3, OUTPUT);

  analogSetPinAttenuation(PIN_MUX_SIG, ADC_0db);
}


// Calibrate Current Sensor at the begining of system start up
void calibrateCurrentSensor(int samples) {
  unsigned long total = 0;
  for (int i = 0; i < samples; i++) {
    total += analogRead(PIN_CURRENT);
    delay(2);
  }

uint32_t avg_raw = total / samples;
uint32_t mv = esp_adc_cal_raw_to_voltage(avg_raw, &adc_chars_current);
float Vsensor = (mv/1000.0f) * ACS_DIV_RATIO; // Undo voltage divider 
current_offset = (Vsensor - ACS_ZERO) / ACS_SENS;  // Calulate offset 

  Serial.print("Current sensor calibrated. Zero offset = ");  //***Note to self if offset is (+ve) it will show negative current value
  Serial.print(current_offset, 3);
  Serial.println(" A");
}


// Mux Voltage reading for one channel
float readMuxVoltage(uint8_t channel) {
  selectMuxChannel(channel);
  delayMicroseconds(10);   // allow signal to settle


  analogRead(PIN_MUX_SIG); // dummy read to clear ADC capacitor

  unsigned long total = 0;

  for(int i = 0; i < ADC_SAMPLES; i++) {
    total += analogRead(PIN_MUX_SIG);
    delay(2);
  }

  uint32_t raw = total / ADC_SAMPLES;

  uint32_t mv = esp_adc_cal_raw_to_voltage(raw, &adc_chars_voltage);

  return (mv / 1000.0f) * VIN_MULTIPLIER;
}

// For loop cycling to measure all mux channels 0-10
void readCellVoltages(float cells[], uint8_t count)
{
    for(uint8_t i = 0; i < count; i++)
    {
        cells[i] = readMuxVoltage(i);
    }
}


// Current reading
float readCurrentACS724() {
  unsigned long total = 0;
  for (int i = 0; i < ADC_SAMPLES; i++) {
    total += analogRead(PIN_CURRENT);
    delay(2);
  }

  uint32_t raw = total / ADC_SAMPLES;
  uint32_t mv = esp_adc_cal_raw_to_voltage(raw, &adc_chars_current);
  float Vsensor = (mv / 1000.0f) * ACS_DIV_RATIO;
  return -(((Vsensor - ACS_ZERO) / ACS_SENS) - current_offset);
}


// Temperature reading for group 1 cells
float getBatteryGroup1Temp() {
  sensorsBatt.requestTemperatures();
  return sensorsBatt.getTempCByIndex(0);
}

// Temperature reading for group 2 cells
float getBatteryGroup2Temp() {
  sensorsBatt2.requestTemperatures();
  return sensorsBatt2.getTempCByIndex(0);
}

// Room Temp reading
float getRoomTemp() {
  sensorsRoom.requestTemperatures();
  return sensorsRoom.getTempCByIndex(0);
}

// Time formatting for serial display. 
String formatTimestamp(unsigned long ms) {
  unsigned long s = ms / 1000UL;
  char buf[16];
  snprintf(buf, sizeof(buf), "%02lu:%02lu:%02lu",
           s / 3600, (s % 3600) / 60, s % 60);
  return String(buf);
}
