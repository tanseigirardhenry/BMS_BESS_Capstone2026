#include "EmailManager.h"
#include "WiFi.h"
#include "SD_MMC.h"
#include <ESP_Mail_Client.h>

#include "Types.h"
#include "SDLogger.h"

extern bool sdBusy;

#define WIFI_SSID       "************" //Wifi Network Name
#define WIFI_PASSWORD   "************"   //Wifi Network passwoard

// SMTP configuration
#define SMTP_HOST       "smtp.gmail.com"    // Change if for differnt type of email.
#define SMTP_PORT       465                 // SSL port for Gmail; Change if for differnt type of email.

#define AUTHOR_EMAIL    "**************"   //Email address we want to send to
#define AUTHOR_PASSWORD "**************"          //Email addresss "APP" password not actual



// Create SMTP session object
SMTPSession smtp;


// Function to initalize wifi connection
void initEmail() {

  // Start WiFi connection
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to WiFi");   // Tell us if wifi connect is successful 

  // Wait until connected
  while (WiFi.status() != WL_CONNECTED) {
    Serial.print(".");
    delay(300);
  }

  Serial.println("\nWiFi connected");
}


// Create email struture
void sendLogEmail(const String& subject) {

  
  while (sdBusy) {        // wait if SD is currently being written
    delay(10);
  }

  sdBusy = true;          // lock SD access
  delay(50);


  // Open log file from SD card
  File file = SD_MMC.open("/log.csv", FILE_READ);
 
  // Read entire file into RAM as a String
  if (!file) {
  Serial.println("Failed to open log.csv");
  sdBusy = false;
  return;
}
  // Read the entire file into RAM 
  String csvData = "";
  while (file.available()) {
   csvData += (char)file.read();
   }
    file.close(); 
    delay(20); // allow SD controller to finish operations
    
    // Create email message object
    SMTP_Message message;

  // Set sender details
  message.sender.name = "BESS Logger";
  message.sender.email = AUTHOR_EMAIL;

   // Set email subject and recipient
  message.subject = subject;
  message.addRecipient("Receiver", AUTHOR_EMAIL);

   // Email body text
  message.text.content = "Attached is the latest SD log file.";

  // Create attachment object
  SMTP_Attachment att;

 

  //message.addAttachment(att);
  att.descr.filename = "log.csv";  // File name shown in email
  att.descr.mime = "text/csv";    // MIME type

   // Attach file from RAM
  att.blob.data = (uint8_t*)csvData.c_str(); 
  att.blob.size = csvData.length();

  // Encode attachment as base64 for email transfer
  att.descr.transfer_encoding = Content_Transfer_Encoding::enc_base64; 
  message.addAttachment(att);
  
  // Configure SMTP session
  ESP_Mail_Session session;
  session.server.host_name = SMTP_HOST;
  session.server.port = SMTP_PORT;
  session.login.email = AUTHOR_EMAIL;
  session.login.password = AUTHOR_PASSWORD;
  session.login.user_domain = "";

  smtp.debug(1); // Enable debug output

  // Connect to SMTP server
  if (!smtp.connect(&session)) {
    Serial.println("SMTP connection failed.");
    sdBusy = false;   // unlock SD
    return;
  }


  // Send Email
  if (!MailClient.sendMail(&smtp, &message)) {
    Serial.println("Email failed:");
    Serial.println(smtp.errorReason());
  }
  else {
    Serial.println("Email sent successfully!");
  }

  //Close SMTP session
  smtp.closeSession();  
  sdBusy = false;       //Unlock SD card access
}