#pragma once
#include "Config.h"
#include "Types.h"


void initEmail();
void sendLogEmail(const String& subject);