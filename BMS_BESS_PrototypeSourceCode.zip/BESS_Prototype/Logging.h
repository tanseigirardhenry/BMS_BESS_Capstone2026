#pragma once

#include "Config.h"
#include "Types.h"

void printBootMessage();
Reading takeReading(unsigned long now);

void logReading(const Reading& r);
void checkOverheat(const Reading& r);

//#pragma once

enum FaultType {
  FAULT_NONE,
  FAULT_THERMAL,
  FAULT_OVERCURRENT,
  FAULT_UNDERVOLTAGE,
  FAULT_OVERVOLTAGE
};

extern FaultType activeFault;


void checkThermal(const Reading& r);
void checkOvercurrent(const Reading& r);
void checkVoltageFault(const Reading& r);

bool shouldDisplay();
void dumpReadings();
void resetDisplayInterval();

