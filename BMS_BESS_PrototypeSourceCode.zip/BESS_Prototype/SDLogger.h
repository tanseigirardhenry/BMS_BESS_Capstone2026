#pragma once
#include "Config.h"
#include "Types.h"


void initSD();
void logToSD(const Reading& r);