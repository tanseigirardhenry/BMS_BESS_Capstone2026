#include <Arduino.h>
#include <ESP_Mail_Client.h>
#include "Config.h"
#include "Types.h"
#include "Sensors.h"
#include "Battery.h"
#include "Logging.h"
#include "SDLogger.h"
#include "EmailManager.h"

bool emailPeriodicPending = false;
bool emailFaultPending = false;
unsigned long lastEmailMs = 0;

void setup() {

  Serial.begin(115200);
  delay(100);

  //Intialize sensors and Calibrate subsystems
  initTemperatureSensors();
  initADC();
  initMUX();

  // To avoid value drift make MUX take mock readings
  float startupVoltages[10];
  readCellVoltages(startupVoltages, 10);  // warm-up read
  delay(10);
  readCellVoltages(startupVoltages, 10);  // real read

  calibrateCurrentSensor();
  initSOCFromVoltage(startupVoltages);
  initSD();
  initEmail();


  printBootMessage();

  lastLogMs = millis();
}

void loop() {
  // put your main code here, to run repeatedly:
  unsigned long now = millis();

  if (now - lastLogMs >= LOG_INTERVAL) {
    lastLogMs += LOG_INTERVAL;

    // Start up reading function for sensors
    Reading r = takeReading(now);

    // Update SOC and SOH with new sensor info
    updateSOC(r.currentA);
    updateSOH(r.cellVoltage);

    // Update per cell temp alg with temp sensor and current sensor information
    estimateCellTemperatures(
      r.battG1TempC, 
      r.battG2TempC, 
      r.currentA
    );

    logReading(r);
    logToSD(r);
    checkThermal(r);
    checkOvercurrent(r);
    checkVoltageFault(r);

    // Fault email has priority
    if (emailFaultPending) {
      sendLogEmail("FAULT DETECTED");
      emailFaultPending = false;
    }


    if (activeFault != FAULT_NONE) {
      //emailPeriodicPending = true;
      return;   // Halt system operations
    }
    
    // Create and send email every 2 mins
    if (now - lastEmailMs >= EMAIL_INTERVAL) {
      lastEmailMs = now;
      emailPeriodicPending = true;
    }


    else if (emailPeriodicPending) {
     sendLogEmail("Periodic Log Update");
      emailPeriodicPending = false;
    }

    // Display values to serial monitor
    if (shouldDisplay()) {
      dumpReadings();          
      resetDisplayInterval(); 
    }
  }

  

  delay(50);
}
