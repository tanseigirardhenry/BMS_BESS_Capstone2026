#pragma once
#include <Arduino.h>

struct Reading {
  unsigned long timestampMs;
  float battG1TempC; 
  float roomTempC; 
  float battG2TempC;
 
  float cellVoltage[10]; 
  float currentA;
};

